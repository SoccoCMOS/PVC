﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace TP3_TPGO.Code_Behind
{
    public class Fils
    {
        public int num;
        public int estim;

        public Fils(int n, int e)
        {
            num = n;
            estim = e;
        }
    }

    class Problem
    {
        int m;
        int n;
        int[] d;

        public Problem(int km, int nb, int[] dist)
        {
            // Données du problème
            this.m = km;
            this.n = nb;
            this.d = new int[nb + 1];
            this.d = dist;
        }

        public List<int> cheminParcouru()
        {
            int B = n + 1;
            int A = 0;
            int sc;

            List<int> stationsArret = new List<int>();
            sc = A; // Sommet initial = racine = A = 0

            while (sc != B)
            {
                ajouterStation(stationsArret, sc); // Ajouter le sommet courant aux stations à parcourir
                // Déterminer la prochaine station
                sc = fils(sc); // Trouver les fils du sommet courant
                //MessageBox.Show(""+sc);
            }
            ajouterStation(stationsArret, B);
            return stationsArret;
        }

        private void ajouterStation(List<int> l, int s)
        {
            l.Add(s);
        }

        private int fils(int sommet)
        {
            int e = 0;
            List<Fils> f = new List<Fils>();
            int j = sommet + 1;
            e = estim(sommet, j);

            while (e >= 0)
            {
                f.Add(new Fils(j, e));
                j++;
                e = estim(sommet, j);
            }
            return optim_station(f); // Calculer la prochaine station de façon à optimiser le fct d'estimation
        }

        private int estim(int s, int k) // Estimation de k à partir de s
        {
            int res = m;
            if ((k > n + 1) || (s > n + 1)) return -1;

            for (int i = s; i < k; i++)
            {
                res -= d[i];
                //MessageBox.Show("ESTIM (" + s + "," + k + ") =" + res);
            }
            return res;
        }

        private int optim_station(List<Fils> fils) // retourne la prochaine station optimale
        {
            //String s="";
            //for (int i = 0; i < fils.Count; i++) s += " " + fils.ElementAt(i).num;
            //MessageBox.Show("FILS " +s);
            return fils.Last().num;
        }
    }
}
