﻿using System.Data;
using System.Windows;
using System;
using TP3_TPGO.Code_Behind;
using System.Collections.Generic;
using System.Linq;

namespace TP3_TPGO
{
    /// <summary>
    /// Interaction logic for result.xaml
    /// </summary>
    public partial class result : Window
    {
        int n;
        int m;
        int[] d;
        DataTable dt = new DataTable();
        public result(uint n , uint m)
        {
            this.n = (int)n;
            this.m = (int) m;
            InitializeComponent();

            for (int k = 0; k <this.n+1; k++)
            {
                dt.Columns.Add(nameStation(k)+"-"+nameStation(k+1), typeof(uint)); 
            }
            //dt.Rows.Add();
            this.dataGrid.ItemsSource = dt.DefaultView;
        }

        private String nameStation(int index)
        {
            if (index == n + 1) return "B";
            switch (index)
            {
                case 0: return "A";
                default: return "S" + index;
            }
        
        }

      private int[] LoadCollectionData()
        {
            return d;
        }

        private void click(object sender, RoutedEventArgs e)
        {
            MainWindow m = new MainWindow();
            m.Show();
            this.Close();
        }

        private void FinalResult(object sender, RoutedEventArgs e)
        {
            String s = "";
            DataView dv = (DataView)this.dataGrid.ItemsSource;
            dt= dv.Table;

            try
            {
                object[] o = dt.Rows[0].ItemArray;

                d = new int[o.Length];
                for (int i = 0; i < o.Length; i++)
                {
                    // Traitement de saisie
                    this.d[i] = Convert.ToInt32(o[i]);

                    if (d[i] > m)
                    {
                        MessageBox.Show("Distance " + nameStation(i)+"-"+nameStation(i+1) + " supérieure au kilométrage maximum. \n Arrêt à la station "+nameStation(i));
                        return;
                    }
                }
            }
            catch
            {
                MessageBox.Show("Veuillez remplir toutes les cases avec des valeurs strictemet positives!");
            }

            Problem p = new Problem(m, n, d);
            List<int> ch = p.cheminParcouru();
            try {
                for (int j = 0; j < ch.Count-1; j++) s += nameStation(ch.ElementAt(j)) + "->" ;
                s += "B";
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
                // Show result
                this.Zoneresultat.Text = s;
        }
    }
}
