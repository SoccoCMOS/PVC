﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TP3_TPGO
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void open(object sender, RoutedEventArgs e)
        {

            uint n;
            uint m;
            try
            {
                 n = Convert.ToUInt32(this.val1.Text);

                 m = Convert.ToUInt32(this.val2.Text);
                if (m == 0 | n < 0)
                {
                    MessageBox.Show("Veuillez entrer des nombres non nulles Svp!");
                }
                else
                {
                    result t = new result(n,m);
                    t.Show();
                    this.Close();
                }
            }
            catch
            {
                MessageBox.Show("Veuillez entrer un nombre Svp!");

            }
        }

        private void exit(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
